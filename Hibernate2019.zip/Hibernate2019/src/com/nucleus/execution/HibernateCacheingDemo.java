package com.nucleus.execution;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;
import com.nucleus.entity.Subject;
import com.nucleus.pojo.Address;

public class HibernateCacheingDemo {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		/*Subject subject=(Subject)session.get(Subject.class,1001);
		System.out.println(subject.getSubCode()+" "+subject.getSubName());*/
		
		//session.evict(subject);
		//session.clear();
		
		Query query1=session.createQuery("from Subject");
		query1.setCacheable(true);
		System.out.println(query1.list());
		
		
		transaction.commit();
		session.close();
		
		
		Session session2=sessionFactory.openSession();
		Transaction transaction2=session2.beginTransaction();
		
		/*Subject subject2=(Subject)session2.get(Subject.class,1001);		
		System.out.println(subject2.getSubCode()+" "+subject2.getSubName());
		subject.setSubName("Computers..");
		*/
		
		Query query2=session2.createQuery("from Subject");
		query2.setCacheable(true);
		System.out.println(query2.list());
		transaction2.commit();
		session2.close();
		sessionFactory.close();

	}

}
