package com.nucleus.execution;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;
import com.nucleus.entity.Subject;
import com.nucleus.pojo.Address;

public class HibernateStates {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		/*Subject subject=new Subject();
		subject.setSubCode(1007);
		subject.setSubName("Sci7"); //transient state
		
		session.persist(subject);  //persistent state
		
		subject.setSubName("Computer Science7");
		subject.setSubName("Computer Science7..1");
		subject.setSubName("Computer Scienc7....2");*/		
		//session.update(subject);
		Subject subject2=(Subject)session.get(Subject.class,1006); //persistent state
		//subject2.setSubName("Geography2");
		transaction.commit();
		session.close();
		
		
		Session session2=sessionFactory.openSession();
		Transaction transaction2=session2.beginTransaction();
		subject2.setSubName("Bio2"); //detached state
		session2.update(subject2); //persistent state
		
		transaction2.commit();
		session2.close();
		sessionFactory.close();

	}

}
