package com.nucleus.execution;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;
import com.nucleus.entity.Subject;
import com.nucleus.pojo.Address;

public class HibernateStates2 {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
	//	Transaction transaction=session.beginTransaction();
		
		Subject subject=new Subject();
		//subject.setSubCode(1008);
		subject.setSubName("BioTech");	
		session.persist(subject);
		//session.save(subject);
		//transaction.commit();
		session.close();
		
		
		/*Session session2=sessionFactory.openSession();
		Transaction transaction2=session2.beginTransaction();
		
		transaction2.commit();
		session2.close();*/
		sessionFactory.close();
System.out.println("Saved");
	}

}
