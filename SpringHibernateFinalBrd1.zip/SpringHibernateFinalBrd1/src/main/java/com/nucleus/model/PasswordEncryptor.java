package com.nucleus.model;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordEncryptor {

	//--------------------Method to encrypt password------------------------
	public String encryptPwd(String pwd) {  
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		String encodedPwd=encoder.encode(pwd);
		
		return encodedPwd;      // returning encoded password
	}
	
}
