package com.nucleus.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="customer18062019")
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private int customerCode;
	private String customerName;
	private String customerAddress;
	private int customerPincode;
	

	private String customerEmail;
	
	private long customerContactNo;
	
	private String customerRegistrationDate;
	
	private String customerCreatedBy;
	

	private String customerModifiedDate;
	
	public int getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getCustomerPincode() {
		return customerPincode;
	}
	public void setCustomerPincode(int customerPincode) {
		this.customerPincode = customerPincode;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public long getCustomerContactNo() {
		return customerContactNo;
	}
	public void setCustomerContactNo(long customerContactNo) {
		this.customerContactNo = customerContactNo;
	}
	
	public String getCustomerCreatedBy() {
		return customerCreatedBy;
	}
	public void setCustomerCreatedBy(String customerCreatedBy) {
		this.customerCreatedBy = customerCreatedBy;
	}
	
	public String getCustomerRegistrationDate() {
		return customerRegistrationDate;
	}
	public void setCustomerRegistrationDate(String customerRegistrationDate) {
		this.customerRegistrationDate = customerRegistrationDate;
	}
	public String getCustomerModifiedDate() {
		return customerModifiedDate;
	}
	public void setCustomerModifiedDate(String customerModifiedDate) {
		this.customerModifiedDate = customerModifiedDate;
	}
	@Override
	public String toString() {
		return "Customer [customerCode=" + customerCode + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPincode=" + customerPincode + ", customerEmail=" + customerEmail
				+ ", customerContactNo=" + customerContactNo + ", customerRegistrationDate=" + customerRegistrationDate
				+ ", customerCreatedBy=" + customerCreatedBy + ", customerModifiedDate=" + customerModifiedDate + "]";
	}
	
	
}
