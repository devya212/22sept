package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.User;

public interface UserDAOInterface {

	public boolean save(User user);
	public List<User> retrieveAll();
	public boolean delete(User user);
	
	public User retrieve(User user);

}
