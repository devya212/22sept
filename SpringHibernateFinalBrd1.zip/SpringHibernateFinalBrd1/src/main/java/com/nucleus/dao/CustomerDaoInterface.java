package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public interface CustomerDaoInterface {
	public boolean save(Customer customer);

	public void delete(Customer customer);
	
	public void delete1(int id);
	
	public void delete2(int id);

	public boolean update(Customer customer);
	
	public Customer retrieve(Customer customer);
	
	public List<Customer> retrieveAll();
	
	public int codeCheck(Customer customer);
}
