package com.nucleus.dao;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer;

@Repository
public class CustomerOracleDaoImpl implements CustomerDaoInterface{

	@Autowired
	SessionFactory sessionFactory;
	JdbcTemplate template;    


	//------------------------Save new customer----------------------------------------------
	@Override
	public boolean save(Customer customer) {
		
		try {
		
		if (retrieve(customer)==null)
		{
			sessionFactory.getCurrentSession().persist(customer);
				
			return true;
		}
		else
		{
			return false;
		}
		
		}catch(Exception e) {
			return false;
		}
	}

	//-------------------------Delete existing customer from database------------------------
	@Override
	public void delete(Customer customer) {
		String code=Integer.toString(customer.getCustomerCode());		
		sessionFactory.getCurrentSession().delete(code, customer); 	
		
	}	
	
	
	@Override
	public void delete2(int id) {
		
			Customer cust=new Customer();
		    cust.setCustomerCode(id);
			sessionFactory.getCurrentSession().delete(cust); 	
		    
		} 
	  
	
	

	//--------------------------Update the existing customer---------------------------------
	@Override
	public boolean update(Customer customer) {
		try {
				System.out.println("In update");
				sessionFactory.getCurrentSession().update(customer);
				System.out.println("@@@@@@");
				return true;
			}catch(Exception e) {
			return false;
			}
	}

	//--------------------------Fetch data from database-------------------------------------
	//Fetch data from databse based on code
	@Override
	public Customer retrieve(Customer customer) {
		Session session=sessionFactory.openSession();
		return (Customer) session.get(Customer.class, customer.getCustomerCode());
	}

	//--------------------------Fetch all customer's detail---------------------------------
	//Fetch data from databse in form of list
	@Override
	public List<Customer> retrieveAll() {
		Session session=sessionFactory.openSession();
		Query query= session.createQuery("from Customer");
		List<Customer> customers=query.list();
		session.close();
		return customers;
	}

	//---------------------------Primary key check------------------------------------------
	//This method use to fetc the existing data of given customer code
	@Override
	public int codeCheck(Customer customer) {
		Session session=sessionFactory.openSession();
		int code=customer.getCustomerCode();
		Query query= session.createQuery(" from Customer where customerCode=:code");  
		query.setParameter("code",code);
		List<Customer> list=query.list();
		if(list.size()==0)
		return 0;
		else return 1;
	}

	@Override
	public void delete1(int id) {
		// TODO Auto-generated method stub
		
	}

	 
		
	}

	

