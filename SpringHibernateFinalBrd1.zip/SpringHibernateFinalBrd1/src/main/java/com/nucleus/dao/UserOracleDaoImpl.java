package com.nucleus.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer;
import com.nucleus.model.PasswordEncryptor;
import com.nucleus.model.User;

@Repository
public class UserOracleDaoImpl implements UserDAOInterface{

	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	PasswordEncryptor pwdEncrypt;
	
	//-------------------------------save query-------------------------------------------
	
	@Override
	public boolean save(User user) {
		try {
		String password=pwdEncrypt.encryptPwd(user.getPassword());   // method called to encrypt password
		user.setPassword(password);		
		if (retrieve(user)==null)
		{
			sessionFactory.getCurrentSession().persist(user);
			return true;
		}
		else
		{
			return false;
		}
		}catch(Exception e) {
			return false;
		}
		
	}
	

	//-------------------------------retrieval query-------------------------------------------
	
	@Override
	public User retrieve(User user) {
		Session session=sessionFactory.openSession();
		return (User) session.get(User.class, user.getUsername());
	}
	
	
	//-------------------------------retreive all query-------------------------------------------

	@Override
	public List<User> retrieveAll() {
		Session session=sessionFactory.openSession();
		Query query= session.createQuery("from User");
		List<User> users=query.list();
		session.close();
		return users;
	}

	
	//-------------------------------delete query-------------------------------------------
	
	@Override
	public boolean delete(User user) {
		try {
		String username=user.getUsername();
		sessionFactory.getCurrentSession().delete(username, user); 	
		return true;
		}catch(Exception e) {
			System.out.println("");
			return false;
		}
		
	}


	

}
