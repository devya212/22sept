
package com.nucleus.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter
{
	
	
	@Autowired
	DataSource dataSource;
	
	@Autowired
	public void configAuthentication(final AuthenticationManagerBuilder auth)throws Exception
	{
		String abc;
		if(dataSource==null)
		{
			System.out.println("in config");
			abc="it is null";
		}
		else
		{
			abc="data received";
		}
		System.out.println("In configAuthentication method of SecurityConfig.:"+abc);
//		auth.inMemoryAuthentication().withUser("priyansh").password("123").roles("ADMIN");
//		auth.inMemoryAuthentication().withUser("User").password("User").roles("USER");
	
		auth.jdbcAuthentication().dataSource(dataSource)
		.passwordEncoder(passwordEncoder())
		.usersByUsernameQuery("select username,password,enabled from userlogin18062019 where username=?")
		.authoritiesByUsernameQuery("select username,role from userlogin18062019 where username=?")
		.getUserDetailsService();
		
	}
	
	
	//---------------Bean to decrypt password-------------------------
	@Bean
	public PasswordEncoder passwordEncoder() {
		PasswordEncoder encoder=new BCryptPasswordEncoder();
		return encoder;
	}
	
	
	@Override
	protected void configure(HttpSecurity http)throws Exception
	{  
		System.out.println("In configure method of SecurityConfig.");
		http.csrf().disable();
		http.headers().frameOptions().sameOrigin();
		http.authorizeRequests()
		.antMatchers("/*Customer").access("hasRole('ROLE_USER')")
		.antMatchers("/*User").access("hasRole('ROLE_ADMIN')")
		.antMatchers("/").permitAll()
		.antMatchers("/loginPage").permitAll()
		.anyRequest().authenticated()
		.and().httpBasic();
		http.authorizeRequests().and().exceptionHandling().accessDeniedPage(("/loginPage"))
		.and().formLogin().loginProcessingUrl("/j_spring_security_check").loginPage("/loginPage").defaultSuccessUrl("/LoginController").failureUrl("/loginPage")
		.usernameParameter("username").passwordParameter("password").and().logout().logoutUrl("/logout");
		
	
		
		
	}
}