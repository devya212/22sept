package com.nucleus.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.nucleus.aop.Logaspect;
import com.nucleus.model.Customer;
import com.nucleus.model.User;




@Configuration
@EnableAspectJAutoProxy
@EnableWebMvc
@PropertySource("classpath:database.properties")

@EnableTransactionManagement
@ComponentScan(basePackages="com.nucleus")
@Import({SecurityConfig.class})
public class AppConfig extends WebMvcConfigurerAdapter{
	
	@Autowired
	  private Environment env;


	
	//-------------------------------------Data source bean---------------------------------------------------------------
	/*@Bean
	public DataSource dataSource() {
		
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		driverManagerDataSource.setUrl("jdbc:oracle:thin:@10.1.50.198:1521:orcl");
		driverManagerDataSource.setUsername("sh");
		driverManagerDataSource.setPassword("sh");
		return driverManagerDataSource;
	}
	*/
	
	
	@Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(env.getProperty("ds.database-driver"));
        dataSource.setUrl(env.getProperty("ds.url"));
        dataSource.setUsername(env.getProperty("ds.username"));
        dataSource.setPassword(env.getProperty("ds.password"));
 
        return dataSource;
    }
	
	

	//-----------------------------------View resolver bean------------------------------------------------------------
	 @Bean
	   public ViewResolver resolver() {
	      InternalResourceViewResolver resolver = new InternalResourceViewResolver();
	      resolver.setViewClass(JstlView.class);
	      resolver.setPrefix("/WEB-INF/views/");
	      resolver.setSuffix(".jsp");
	      return resolver;
	   }
	 
	 //--------------------------------Session factory bean------------------------------------------------------------
	@Bean(name="sessionFactory")
	public SessionFactory getSessionFactory() {
		Properties hibernate=new Properties();
		hibernate.put("hibernate.dialect","org.hibernate.dialect.Oracle10gDialect");
		hibernate.setProperty("hibernate.hbm2ddl.auto","update");
		hibernate.setProperty("hibernate.show_sql","true");
		LocalSessionFactoryBuilder localSessionFactoryBuilder=new LocalSessionFactoryBuilder(dataSource());
		localSessionFactoryBuilder.addProperties(hibernate);
		localSessionFactoryBuilder.addAnnotatedClass(Customer.class);
		localSessionFactoryBuilder.addAnnotatedClass(User.class);
		SessionFactory sessionFactory=localSessionFactoryBuilder.buildSessionFactory();
		
		
		return sessionFactory;
		
	}
	 
	 
	//-------------------------------------Transaction manager bean----------------------------------------------------
	  @Autowired
	  @Bean(name = "transactionManager")
	  public DataSourceTransactionManager getTransactionManager(DataSource dataSource) {
	      DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
	 
	      return transactionManager;
	  }
	  
	  @Bean // the Aspect itself must also be a Bean
	     public Logaspect myAspect() {
	         return new Logaspect();
	     }
	  
}
