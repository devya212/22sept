package com.nucleus.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class Logaspect 
{
	Logger log1=Logger.getLogger(Logaspect.class.getName());
	@Before("execution(* com.nucleus.dao.UserDAOInterface.*(..))")
	public void start(JoinPoint point)
	{  
		log1.info("logger is running");

	}
	
	@After("execution(* com.nucleus.dao.UserDAOInterface.*(..))")
	public void end(JoinPoint point)
	{

		log1.info("logger is running");

	}
	
	@Around("execution (* com.nucleus.dao.UserDAOInterface.*(..))")
	public Object around(ProceedingJoinPoint process)throws Throwable
	{
		Object object=null;
		try
		{
			object=process.proceed();

			log1.info("logger is running");

		}
		catch(Throwable e)
		{

			log1.info("logger is running");
	
}
		return object;
	}   
}
