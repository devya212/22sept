package com.nucleus.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.UserDAOInterface;
import com.nucleus.model.User;

@Service
@Transactional
public class UserServiceImpl implements UserServiceInterface{
	@Autowired
	UserDAOInterface userDao;

	@Override
	public boolean save(User user) {
		
		return userDao.save(user);
	}

	@Override
	public List<User> retrieveAll() {
		
		return userDao.retrieveAll();
	}

	@Override
	public boolean delete(User user) {
		return userDao.delete(user);
		
	}
}
