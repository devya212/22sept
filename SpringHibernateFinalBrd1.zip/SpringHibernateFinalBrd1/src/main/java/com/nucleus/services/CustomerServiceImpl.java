package com.nucleus.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.nucleus.dao.CustomerDaoInterface;
import com.nucleus.model.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerServiceInterface{
	
	@Autowired
	CustomerDaoInterface customerDao;
	JdbcTemplate template;    

	@Override
	public boolean save(Customer customer) {
		return customerDao.save(customer);
	}

	@Override
	public void delete(Customer customer) {
		customerDao.delete(customer);
		}

	@Override
	public void delete1(int id) {
		customerDao.delete1(id);

			}
	
	
	
	@Override
	public void delete2(int id) {
		customerDao.delete2(id);

			}
	
	
	@Override
	public boolean update(Customer customer) {
		System.out.println("test service");
		return customerDao.update(customer);	
	}

	@Override
	public Customer retrieve(Customer customer) {
		System.out.println("In retrive service");
		return customerDao.retrieve(customer);	
	}

	@Override
	public List<Customer> retrieveAll() {
		return customerDao.retrieveAll();	
	}

	@Override
	public int codeCheck(Customer customer) {
		return customerDao.codeCheck(customer);
	}
}
