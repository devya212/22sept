package com.nucleus.services;

import java.util.List;

import com.nucleus.model.Customer;
import com.nucleus.model.User;

public interface UserServiceInterface {

	boolean save(User user);
	public List<User> retrieveAll();
	public boolean delete(User user);
	
}
