package com.nucleus.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Customer;
import com.nucleus.services.CustomerServiceInterface;

@Controller
@SessionAttributes("username")
public class CustomerController {
	
	@Autowired
	CustomerServiceInterface customerService;
	
	Date date = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String strDate= formatter.format(date);
    
    //-------------------URL and View pages-------------------------
    
    
    @RequestMapping(value="/loginPage",method=RequestMethod.GET)
	public String goToLogin() {
		return "login";
	}

	@RequestMapping(value="/logs",method=RequestMethod.GET)
	public String goToUserHome() {
		return "user";
	}
	@RequestMapping(value="/userHome",method=RequestMethod.GET)
	public String homeUser() {
		return "user";
	}
	
	//-------------for add customer------------------------------------------------
	
	@RequestMapping(value="/addCustomer",method=RequestMethod.GET)  
	public String displayMap(@ModelAttribute("customer")Customer customer)  
		{  		
			return "addCustomer";  
		}  
	
	
	@RequestMapping(value="/addCustomer1",method=RequestMethod.POST)
	public String saveCustomer(@ModelAttribute("customer")Customer customer, BindingResult errors,Model model1) {
		if(errors.hasErrors()) {
			return "addCustomer";
		}
		System.out.println(strDate);
		customer.setCustomerRegistrationDate(strDate);
		boolean b=customerService.save(customer);
		if(b==true) {
			model1.addAttribute("message","Record Saved");
			return "addCustomer" ;
		}else {
			model1.addAttribute("message", "customer code already exists");
			return "addCustomer" ;
		}
		
		}

	//-------------delete customer------------------------------------------------
	
	
	
	
	@RequestMapping(value="/deleteCustomer2/{customerCode}",method = RequestMethod.GET)    
    public String delete(@PathVariable int customerCode){    
        
		//customerService.delete(customerCode);
		
		customerService.delete2(customerCode);

        return "redirect:/viewAllCustomer1";    
    }     
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/deleteCustomer",method=RequestMethod.GET)  
		public String displayDelete(@ModelAttribute("customer")Customer customer)  
			{  		
				return "deleteCustomer";  
			}  

	@RequestMapping(value="/deleteCustomer1",method=RequestMethod.GET)
	public String delete(@ModelAttribute("customer")Customer customer, BindingResult errors,Model model1)  
	{  	
		if(errors.hasErrors()) {
			return "deleteCustomer"; 
		}
		
		int i=customerService.codeCheck(customer);
		if(i==1) {
			customerService.delete(customer);
			model1.addAttribute("message","Record deleted successfully");  
			return "deleteCustomer";  
		}else {
			model1.addAttribute("message","Invalid customer Code");  
			return "deleteCustomer"; 
		}
		
	}  
	
	
	//-------------view single customer------------------------------------------------
	
	
	@RequestMapping(value="/viewCustomer",method=RequestMethod.GET)  
	public String view(@ModelAttribute("customer")Customer customer)  
		{  		
			return "viewCustomer";  
		}  
	
	@RequestMapping(value="/viewCustomer1",method=RequestMethod.GET)  
	public ModelAndView viewOne(@ModelAttribute("customer")Customer customer,Model model1)  
		{  	

			int i=customerService.codeCheck(customer);
			if(i==1) {
				customer=customerService.retrieve(customer);
				model1.addAttribute("customer",customer);
				return new ModelAndView("viewSingleCustomer","customer",customer);			
				}
			return new ModelAndView("user","customer",customer);	
		} 
	
	
	//-------------view all customer------------------------------------------------
	
	@RequestMapping(value="/viewAllCustomer",method=RequestMethod.GET)  
	public String ViewAllCustomer(Model model)
		{  		
			List<Customer> customers =customerService.retrieveAll();
			model.addAttribute("customers",customers);
			return "viewAllCustomer";	
		}  
	
	@RequestMapping(value="/viewAllCustomer1",method=RequestMethod.GET)  
	public String ViewAllCustomer1(Model model)
		{  		
			List<Customer> customers =customerService.retrieveAll();
			model.addAttribute("customers",customers);
			return "viewAllCustomer1";	
		}  
	
	
	//-------------update customer------------------------------------------------
	
	
	
	@RequestMapping(value="/updateCustomer",method=RequestMethod.GET)  
	public ModelAndView displayUpdate(@ModelAttribute("customer") Customer customer)  
		{  		
			return new ModelAndView("updateCustomer","count",0);  
		}  

	
	@RequestMapping(value="/updateCustomer1")  
	public String UpdateCustomer(@ModelAttribute("customer") Customer customer,Model model1)  
		{  	
		
			int i=customerService.codeCheck(customer);
			System.out.println("hello");
			if(i==1) {
				Customer customer1=customerService.retrieve(customer);
				System.out.println(customer1);
				customer1.setCustomerModifiedDate(strDate);
				model1.addAttribute("customer",customer1);
				System.out.println(customer1);
				return  "updateCustomer1";	
				}
			return "user";	
		}  
	
	@RequestMapping(value="/updateCustomer2", method=RequestMethod.POST)
	public String updateCustomer1(@ModelAttribute("customer") @Valid Customer customer,BindingResult errors,Model model){
		
		if ((errors.hasErrors())) {
			return "updateCustomer";
		}
		
		boolean result =customerService.update(customer);
		if (result == true) {
			model.addAttribute("message","Customer record Updated");
		} else {
			model.addAttribute("message","Customer record not Updated");
		}
		return "updateCustomer1";
	}
	
		
	
}
