package com.nucleus.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.nucleus.model.User;
import com.nucleus.services.UserServiceInterface;


@Controller
public class UserController {
	
	@Autowired
	UserServiceInterface userService;
	
	
	
	/*@RequestMapping(value="/log",method=RequestMethod.GET)
	public String goToHome() {
		return "admin";
	}*/
	@RequestMapping(value="/Home",method=RequestMethod.GET)
	public String home() {
		return "admin";
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout() {
		return "login";
	}

	@RequestMapping(value="/save",method=RequestMethod.GET)  
	public String display(@ModelAttribute("user")User user)  
		{  		
			return "addUser";  
		}  
	
	//-------------for adding user------------------------------------------------
	
	
	
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public String save(@Valid@ModelAttribute("user")User user, BindingResult errors,Model model) {
		if(errors.hasErrors()) {
			return "addUser" ;
		}
		boolean b=userService.save(user);
		if(b==true) {
			model.addAttribute("message","Record Saved");
			return "admin";
		}else {
			model.addAttribute("message", "Username already exists");
			return "addUser" ;
		}	
	}
	
	
	//-------------delete user------------------------------------------------
	
	
		@RequestMapping(value="/deleteUser",method=RequestMethod.GET)  
			public String displayDelete(@ModelAttribute("user")User user)  
				{  		
					return "deleteUser";  
				}  

		@RequestMapping(value="/deleteUser1",method=RequestMethod.GET)
		public String delete(@ModelAttribute("user")User user, BindingResult errors,Model model1)  
		{  	
			if(errors.hasErrors()) {
				return "deleteUser"; 
			}
			boolean b=userService.delete(user);
			if(b==true) {
				model1.addAttribute("message","Record deleted successfully");  
				return "deleteUser";  
			}else {
				model1.addAttribute("message","Invalid customer Code");  
				return "deleteUser"; 
			}
			
		}  
	
		//-------------view all user------------------------------------------------	
		
		
		
	@RequestMapping(value="/viewAllUser",method=RequestMethod.GET)  
	public String GoToViewAll(Model model)
		{  		
			List<User> users =userService.retrieveAll();
			model.addAttribute("users",users);
			return "viewAllUser";	
		}  
}
