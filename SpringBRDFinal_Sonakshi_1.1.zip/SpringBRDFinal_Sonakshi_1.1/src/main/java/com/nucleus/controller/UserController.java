/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nucleus.model.persistence.dao.UserDao;
import com.nucleus.model.persistence.entity.Customer;
import com.nucleus.model.persistence.entity.User;
import com.nucleus.service.ServiceDao;
//**************************Controller********************************

@Controller
@RequestMapping
public class UserController {
	
	private static final String index="index";
	private static final String welcome="welcome";
	private static final String welcomepage="welcomepage";
	private static final String NewUser="NewUser";
	private static final String UpdateUser="UpdateUser";
	private static final String DeleteUser="DeleteUser";
	private static final String showCustomer="showCustomer";
	private static final String ViewOne="ViewOne";
	private static final String ViewOneTable="ViewOneTable";
	private static final String viewOneByName="viewOneByName";
    private static final String ViewName="ViewName";
	private static final String ViewAll="ViewAll";
	private static final String UpdateDetails="UpdateDetails";
	private static final String AddNewUser="AddNewUser";
	private static final String error="error";
	private static final String ShowNewUser="ShowNewUser";
	
	
	
	
	final static Logger logger=Logger.getLogger(UserController.class);
	@Autowired
	 private UserDao userDao;
		
/////*********login*******************
	//Default mapping for application
	 @RequestMapping(value="/login")
	 public String ShowLoginForm(){
		 logger.info("lgoin form");
		 return index;
	 }
	 
	//Get Mapping for page
	 @RequestMapping(value="/",method=RequestMethod.GET)
	 public String Home( Model model,Authentication authentication,HttpServletRequest req) {
		 authentication.getPrincipal();
		for (GrantedAuthority a : authentication.getAuthorities()) {
			//session
			HttpSession httpSession =req.getSession(false);
			httpSession.setAttribute("name",authentication.getName());
			
			String role=a.getAuthority();
			//opening page according to the role
			if("ROLE_ADMIN".equals(role))
			{
				logger.info("admin page");
				httpSession.setMaxInactiveInterval(6*60);
				  return welcome;  
			}
			
			else{
				logger.info("user page");
				httpSession.setMaxInactiveInterval(6*60);
				return welcomepage;
			}
		}
		return null;  
	 }
	//Customer page 
	@RequestMapping(value="/welcomeUser")
	public String showWelcome(){
		return welcomepage;
	}
	//Admin Page
	@RequestMapping(value="/welcomeAdmin")
	public String showWelcomeUser(){
		return welcome;
	}
	 
	 
	 
	 
		@Autowired
		private ServiceDao serviceDao;
		
// ***************add****************************************************
		//Get Mapping to add customer
		@RequestMapping(value ="/adduser", method= RequestMethod.GET)
		public String adduser(Model m)
		{
			
			m.addAttribute("customer",new Customer());
			return NewUser;
			
		}
		//Post Mapping to add customer
		@RequestMapping(value ="addnewuser", method= RequestMethod.POST)
		public String addnewUser(@Valid @ModelAttribute("customer") Customer customer,BindingResult result, Model model){
			if(result.hasErrors()){
				return NewUser;
			}else{
				//checking if customer doest not already exist
			if(!serviceDao.isValidCode(customer.getCustomerCode())){
				
				logger.info("adding new customer [Controller]");
				customer.setCreateDate(new Date());
				serviceDao.addcustomer(customer);   //will initially go to daoimpl
				model.addAttribute(new Customer());
				return "NewUser";
			}
			else{
				String message="User already exist";
				model.addAttribute("message", message);
				return NewUser;
			}}
		}

//****************delete******************************************************************
		//Get Mapping to delete customer
		@RequestMapping(value ="/deleteuser", method= RequestMethod.GET)
		public String deleteuser()
		{
			
			return DeleteUser;	
		}
		//post Mapping to delete customer
		@RequestMapping(value ="/delete", method= RequestMethod.POST)
		public String delete(Model model,@RequestParam("customerCode") String customerCode){
			//is there a valid code to delete
			if(serviceDao.isValidCode(customerCode)){
				System.out.println(customerCode);
			serviceDao.deleteCustomer(customerCode);	
			return showCustomer;
			}
			//if not valid code
			else{
				String message="User doesnot exist";
				model.addAttribute("message", message);
				return DeleteUser;
			}
			
		}
	//******************view one **********************************************************
		//Get Mapping to view customer
		@RequestMapping(value ="/viewuser", method= RequestMethod.GET)
		public String viewuser()
		{
			
			
			return ViewOne;
			
		}
		//post Mapping to view customer
		@RequestMapping(value ="/oneview", method= RequestMethod.POST)
		public String oneview(Model model,@RequestParam("customerCode") String customerCode){
			//is there a valid code to view
			if(serviceDao.isValidCode(customerCode)){
			
			Customer customer = serviceDao.viewCustomer(customerCode);
			model.addAttribute("customer", customer);
			return ViewOneTable;
			}
			else{
				String message="user doesnot exist";
				model.addAttribute("message", message);
				return ViewOne;
			}
		}
//***************ViewByCustomerName********************		
		//Get Mapping to viewbyNmae customer
		@RequestMapping(value ="/viewusername", method= RequestMethod.GET)
		public String viewuserByName()
		{
			
			
			return viewOneByName;
			
		}
		//post Mapping to view customer
		@RequestMapping(value ="/viewByName", method= RequestMethod.POST)
		public String viewByname(Model model,@RequestParam("customerName") String customerName){
			//is there a valid code to view
			if(serviceDao.isValidName(customerName)){
				
			List<Customer> customer = serviceDao.viewCustomerByName(customerName);
			model.addAttribute("customer", customer);
			return ViewName;
			}
			else{
				String message="user doesnot exist";
				model.addAttribute("message", message);
				return viewOneByName;
			}
		}	
		
		
		//****************viewall*********************
		
		//Get Mapping to view all  customer
		@RequestMapping(value="/viewall", method = RequestMethod.GET)
		public String viewAll(Model model){
			
			List<Customer> customer = serviceDao.viewAll();
			
			model.addAttribute("customer", customer);
			
			return ViewAll;
					
			
		}
		//**************update***************
		//Get Mapping to update customer
		@RequestMapping(value="/update", method = RequestMethod.GET)
		public String updateUser(){
			return UpdateUser;
				
		}
		//post Mapping to update customer
		//will bring the pre-popullated form
		@RequestMapping(value="/updatevalue",method = RequestMethod.POST)
		public String updateValue(Customer customer,Model model,@RequestParam("customerCode") String customerCode){
			
			//is there a valid code to view
			if(serviceDao.isValidCode(customerCode)){
				
		   customer = serviceDao.viewCustomer(customerCode);
			model.addAttribute("customer", customer);
			
			return UpdateDetails;
			}
			else{
				String message="user doesnot exist";
				model.addAttribute("message", message);
				return UpdateUser;
			}
					
		}
		//post Mapping to update customer
		@RequestMapping(value="/updated", method = RequestMethod.POST)
		public String updated(@Valid @ModelAttribute("customer")  Customer customer,BindingResult result){
			if(result.hasErrors())
			{return UpdateDetails;}
			else{
				customer.setModifiedDate(new Date());
			serviceDao.updateCustomer(customer);
			return showCustomer;
			}		
		}
		
	//*********************AddNewUser******************************	
		//get Mapping to add user
		@RequestMapping(value ="/add", method= RequestMethod.GET)
		public String addNewuser(Model m,Authentication authentication)
		{
			for (GrantedAuthority a : authentication.getAuthorities()) {
			
				
				String role=a.getAuthority();
				if(role.equals("ROLE_ADMIN"))
				{m.addAttribute("user",new User());
					  return AddNewUser;  
				}
				else
					return error;
					
			}
			
			return null;
			
		}
		//post Mapping to add user
		@RequestMapping(value ="/addnew", method= RequestMethod.POST)
		public String add(@Valid @ModelAttribute("user")User user,BindingResult result, Model model){
			
			
			if(result.hasErrors()){
				return AddNewUser;
			}else{
			
				
				model.addAttribute(user);
			
				serviceDao.addNewUser(user);
			
			
			return ShowNewUser;
			}
		}
			
	 	
	}


