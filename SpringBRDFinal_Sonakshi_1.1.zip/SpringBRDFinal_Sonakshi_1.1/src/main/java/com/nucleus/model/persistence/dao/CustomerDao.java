/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.model.persistence.dao;

import java.util.List;

import com.nucleus.model.persistence.entity.Customer;



public interface CustomerDao {
	public List<Customer> getAllCustomers();
	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public Customer deleteCustomer(String customerCode);
	public Customer viewCustomer(String customerCode);
	public List<Customer> viewCustomerByName(String customerName);
	public boolean isValidCode(String customerCode);
	public boolean isValidCustomerName(String customerName);
}

