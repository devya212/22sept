/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.model.persistence.dao;

import java.util.Date;
import java.util.List;





import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.persistence.entity.Profile;
import com.nucleus.model.persistence.entity.User;



@Repository
public class UserDaoImpl implements UserDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	protected Session getSession()
	{
		return sessionFactory.getCurrentSession();
	}
	
	@Transactional
	public boolean validate(String name, String pass) {
		Session currentSession=sessionFactory.getCurrentSession();
		
		Query q = currentSession
				.createQuery("select u from User u where u.userName=:name and u.password=:password");
		q.setString("name", name);
		q.setString("password", pass);

		@SuppressWarnings("unchecked")
		List<User> list = q.list();
		if (!list.isEmpty()) {
			System.out.println("something is found!");
			User user = list.get(0);
			System.out.println(user);
			
			return true;
			
		} else {
			System.out.println("user not found");
		}
		
		return false;	
		
	}
@Transactional
	public User getUser(String userName) {
		System.out.println("Query Fire hua");
		
		User user = null;
		Query query = getSession().createQuery(
				"select u from User u where u.userName=:name");
		query.setString("name", userName);
		
	System.out.println("hi");

		@SuppressWarnings("unchecked")
		List<User> usr = query.list();
		System.out.println(usr+"hhhhhhhhhhhh");
System.out.println(usr.size());
		if (usr.size()>0) {
			System.out.println("hiiiiii");
			user=usr.get(0);
			//System.out.println(user.getPassword());
			//System.out.println(user.getUserName());
			
			
			return usr.get(0);
		} else {
			
			System.out.println("Else part ");
			return null;
		}
	}

@Override
@Transactional
public User addNewUser(User user) {
	System.out.println(user);
	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
	user.setUserPassword(encoder.encode(user.getUserPassword()));
	if(user.getProfile().getProfile().equals("ROLE_ADMIN")){
		user.getProfile().setId(1);
		getSession().save(user);
	}
	if(user.getProfile().getProfile().equals("ROLE_USER")){
		user.getProfile().setId(2);
		getSession().save(user);
	}
	//System.out.println("sonakshi");
	return user;
	
}

	}
	

