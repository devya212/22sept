/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.model.persistence.dao;

import com.nucleus.model.persistence.entity.Customer;
import com.nucleus.model.persistence.entity.User;

public interface UserDao {
	public  boolean validate(String name,String pass);
	 public User getUser(String userName);
	 public User addNewUser(User user);
}
