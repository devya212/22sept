/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.model.persistence.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="User_BRD")
public class User implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="UserSequence1276")
	@SequenceGenerator(name="UserSequence1276",initialValue=4,allocationSize=1)
	@Column(name="User_Id",length=10)
	private int userId;
	
	@Column(name="User_Name",length=50)
	@NotEmpty(message="is required")
	private String userName;
	
	
	@Column(name="Password",length=100)
	@NotEmpty(message="is required")
	private String userPassword;
	
	@Column(name="enabled",length=255)
	private String enabled;
	
	@ManyToOne (cascade = {CascadeType.ALL})

	@JoinColumn(name = "profile_id_fk")
	private Profile profile;
	
	
	
	
	
	public User(String userName, String password, String enabled,Profile profile) {
		super();
		
		this.userName = userName;
		this.userPassword = password;
		this.enabled = enabled;
		this.profile=profile;
	}




	public User() {
	}




	public String getUserName() {
		return userName;
	
	}
	
	public int getUserId() {
		return userId;
	}
	
	public String getUserPassword() {
		return userPassword;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getEnabled() {
		return enabled;
	}


	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}


	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPassword=" + userPassword + ", profile="
				+ profile + "]";
	}

	
	
}






























