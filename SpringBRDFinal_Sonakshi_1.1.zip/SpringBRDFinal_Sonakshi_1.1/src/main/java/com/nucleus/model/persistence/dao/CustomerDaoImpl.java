/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.model.persistence.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.controller.UserController;
import com.nucleus.model.persistence.entity.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	final static Logger logger=Logger.getLogger(CustomerDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	protected Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> getAllCustomers() {
		try {
			logger.debug("inside Try Bolock");
			return (List<Customer>) getSession().createCriteria(Customer.class)
					.list();
			
		} catch (Exception e) {
			logger.error("inside Catch Block of get All Customers");
			return null;
		}
	}

	@Override
	public Customer addCustomer(Customer customer) {

		try {
			getSession().save(customer);
			return customer;
		} catch (Exception e) {
			
			return null;
		}
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		try {
			Customer customer2 = viewCustomer(customer.getCustomerCode());
			customer2.setContactNumber(customer.getContactNumber());
			customer2.setCustomerAddressOne(customer.getCustomerAddressOne());
			customer2.setCustomerName(customer.getCustomerName());
			customer2.setCustomerPinCode(customer.getCustomerPinCode());
			customer2.setEmailAddress(customer.getEmailAddress());
			customer2.setModifiedDate(customer.getModifiedDate());
			getSession().merge(customer2);
			return customer;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public Customer deleteCustomer(String customerCode) {
		try {

			Customer customer = new Customer();

			Query q = getSession()
					.createQuery(
							"select c from Customer c  where c.customerCode=:customercode");
			q.setString("customercode", customerCode);

			@SuppressWarnings("unchecked")
			List<Customer> cust = q.list();
			if (cust.size() > 0) {
				customer = cust.get(0);
				getSession().delete(customer);

			}

			return customer;
		} catch (Exception e) {
			return null;
		}

	}

	@Override
	public Customer viewCustomer(String customerCode) {
		try {
			Customer cust = null;
			Query query = getSession()
					.createQuery(
							"select u from Customer u where u.customerCode=:customerCode");
			query.setParameter("customerCode", customerCode);

			@SuppressWarnings("unchecked")
			List<Customer> customer = query.list();
			if (!customer.isEmpty()) {
				cust = customer.get(0);
			}

			return cust;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean isValidCode(String customerCode) {
		try {
			Query q = getSession()
					.createQuery(
							"select u from Customer u where u.customerCode=:customerCode ");
			q.setString("customerCode", customerCode);

			@SuppressWarnings("unchecked")
			List<Customer> list = q.list();

			if (!list.isEmpty()) {

				Customer customer = list.get(0);

				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}

	}


	@Override
	public List<Customer> viewCustomerByName(String customerName) {

		try{
		Query query = getSession().createQuery(
				"select u from Customer u where u.customerName=:customerName");
		query.setParameter("customerName", customerName);

		List<Customer> customer = query.list();
		if (!customer.isEmpty()) {
			return customer;
		} else
			return null;
		}catch(Exception e){
			return null;
		}
	}

	@Override
	public boolean isValidCustomerName(String customerName) {
		try{
		Query q = getSession().createQuery(
				"select u from Customer u where u.customerName=:customerName ");
		q.setString("customerName", customerName);

		@SuppressWarnings("unchecked")
		List<Customer> list = q.list();

		if (!list.isEmpty()) {

			Customer customer = list.get(0);
			

			return true;

		} else {
			
			return false;
		}
		}catch(Exception e){
			return false;
		}

	}
}
