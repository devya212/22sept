/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.model.persistence.entity;
import java.io.Serializable;
import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Customer_1276")
public class Customer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Id
	@Column(name="customer_code",length=10)
	@NotEmpty
	@Pattern(regexp="^[0-9]+$")
	@Size(min=1, max=10)
	private String customerCode;
	
	public Customer() {
		super();
	}

	
	@Column(name="customer_name",length=30)
	@Pattern(regexp="^[a-zA-Z0-9 ]*$")
	@Size(max=30)
	@NotEmpty
	private String customerName;
	
	
	@Column(name="customer_address",length=100)
	@NotEmpty
	@Size(max=100)
	private String customerAddressOne;
	
	@Column(name="customer_pinCode",length=6)
	@NotEmpty
	@Size(max=6,min=6)
	@Pattern(regexp="^[0-9]+$", message="must be a digit")
	private String customerPinCode;
	
	
	@Column(name="customer_email",length=100)
	@NotEmpty
	@Size(max=100)
	@Email
	private String emailAddress;
	
	@Column(name="customer_phone",length=20)
	@NotEmpty
	@Size(min=10,max=10)
	@Pattern(regexp = "^[0-9]+$")
	private String contactNumber;
	
	@Temporal(TemporalType.DATE) @Column(name="create_date")
	private Date createDate;
	
	@Column(name="customer_createdby",length=10)
	@NotEmpty
	private String createdBy;
	
	
	@Temporal(TemporalType.DATE) @Column(name="modified_date")
	private Date modifiedDate;
	
	
	public String getCustomerCode() {
		return customerCode;
	}
	
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddressOne() {
		return customerAddressOne;
	}
	public void setCustomerAddressOne(String customerAddressOne) {
		this.customerAddressOne = customerAddressOne;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Customer(String customerCode, String customerName, String customerAddressOne, String customerPinCode,
			String emailAddress, String contactNumber, Date createDate, String createdBy, Date modifiedDate) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddressOne = customerAddressOne;
		this.customerPinCode = customerPinCode;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.modifiedDate = new Date();
	}

	@Override
	public String toString() {
		return "Customer [customerCode=" + customerCode + ", customerName=" + customerName + ", customerAddressOne="
				+ customerAddressOne + ", customerPinCode=" + customerPinCode + ", emailAddress=" + emailAddress
				+ ", contactNumber=" + contactNumber + ", createDate=" + createDate + ", createdBy=" + createdBy
				+ ", modifiedDate=" + modifiedDate + "]";
	}
	
	
	
	


}
















































/*import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Customer_1227")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE) 
	private int customerId;
	@Column(nullable=false,unique=true)
	@NotEmpty(message="is required")
	private String customerCode;
	
	@NotEmpty(message="is required")
	private String customerName;
	
	@NotEmpty(message="is required")
	private String customerAddress1;
	
	@NotEmpty(message="is required")
	private String customerAddress2;
	
	@NotEmpty(message="is required")
	@Size(max=6,min=6)
	@Pattern(regexp="^[0-9]+$", message="must be a digit")
	private String customerPinCode;
	
	@NotEmpty(message="is required")
	@Email
	private String emailAddress;
	@NotEmpty(message="is required")
	@Size(min=10,max=10)
	@Pattern(regexp = "[0-9]+", message = "Invalid Contact Number")
	private String contactNumber;
	
	@NotEmpty(message="is required")
	private String primaryContactPerson;
	
	private String recordStatus;
	private String Flag;
	@Temporal(TemporalType.DATE)
	private Date createDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	
	public Customer(String customerCode,
			String customerName, String customerAddress1,
			String customerAddress2, String customerPinCode,
			String emailAddress, String contactNumber,
			String primaryContactPerson, String recordStatus,
			String createdBy,String flag) {
		super();
	//	this.customerId = customerId;
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPinCode = customerPinCode;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.primaryContactPerson = primaryContactPerson;
		this.recordStatus = recordStatus;
		this.Flag = flag;
		this.createDate = new Date();
		this.createdBy = createdBy;
		//this.modifiedDate = modifiedDate;
		//this.modifiedBy = modifiedBy;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress1() {
		return customerAddress1;
	}
	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}
	public String getCustomerAddress2() {
		return customerAddress2;
	}
	public void setCustomerAddress2(String customerAddress2) {
		this.customerAddress2 = customerAddress2;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPrimaryContactPerson() {
		return primaryContactPerson;
	}
	public void setPrimaryContactPerson(String primaryContactPerson) {
		this.primaryContactPerson = primaryContactPerson;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getFlag() {
		return Flag;
	}
	public void setFlag(String Flag) {
		this.Flag = Flag;
	}
	public Date getCreateDate() {
		return createDate;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress1=" + customerAddress1 + ", customerAddress2=" + customerAddress2
				+ ", customerPinCode=" + customerPinCode + ", emailAddress=" + emailAddress + ", contactNumber="
				+ contactNumber + ", primaryContactPerson=" + primaryContactPerson + ", recordStatus="
				+ recordStatus + ", Flag=" + Flag + ", createDate=" + createDate + ", createdBy=" + createdBy
				+ ", modifiedDate=" + modifiedDate + ", modifiedBy=" + modifiedBy + "]";
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
}
*/