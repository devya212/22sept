/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.service;

import java.util.List;

import com.nucleus.model.persistence.entity.Customer;
import com.nucleus.model.persistence.entity.User;

public interface ServiceDao {

	public Customer addcustomer(Customer customer);
	public void deleteCustomer(String customerCode );
	public Customer viewCustomer(String customerCode );
	public List<Customer> viewCustomerByName(String customerName );
	public void viewallCustomer();
	public List<Customer> viewAll();
	public void updateCustomer(Customer customer);
	public User findByUsername(String userName);
	 public User addNewUser(User user);
	 public boolean isValidCode(String customerCode);
	public boolean isValidName(String customerName);
}

