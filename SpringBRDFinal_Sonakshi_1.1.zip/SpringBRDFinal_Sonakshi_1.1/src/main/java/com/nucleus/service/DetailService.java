/*
 * Author-Sonakshi Malhotra
 * Modified Date-Aug 19, 2018
 * Version-1.0
 * 
 * */

package com.nucleus.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.persistence.entity.User;
@Service(value="detailService")
@Transactional(readOnly=true)
public class DetailService implements UserDetailsService{
	@Autowired
	private ServiceDao  serviceDao;
	
	@SuppressWarnings("unused")
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException {
		//System.out.println(userName);
		
		User user=serviceDao.findByUsername(userName);
		System.out.println("Detail Service");
		System.out.println(user);
		//System.out.println(user.getProfile().getProfile());
		
		if(user==null)
			throw new UsernameNotFoundException("username is not found");
		return new org.springframework.security.core.userdetails.User(user.getUserName(),user.getUserPassword(),
				AuthorityUtils.createAuthorityList(user.getProfile().getProfile()));

		
	}
	

}

