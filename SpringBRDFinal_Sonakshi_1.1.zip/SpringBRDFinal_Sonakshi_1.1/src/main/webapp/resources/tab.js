function tabIndex(){
	document.getelementById('1').tabindex="=-1"
		document.getelementById('2').tabindex="2"
			document.getelementById('3').tabindex="3"
				document.getelementById('4').tabindex="4"
					document.getelementById('5').tabindex="5"
						document.getelementById('6').tabindex="6"
							document.getelementById('7').tabindex="-1"
}

///*******************************************************************	
/*function setFocus{
    document.getElementById("1").focus();
    document.getElementById("2").focus();
    document.getElementById("3").focus();
    document.getElementById("4").focus();
    document.getElementById("txtEmail").focus();
    document.getElementById("6").focus();
    document.getElementById("7").focus();
}
*/