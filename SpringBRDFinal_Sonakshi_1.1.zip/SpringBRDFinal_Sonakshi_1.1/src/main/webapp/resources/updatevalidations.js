function validation()
{
var numbers = /^[0-9]+$/;
var con=document.userForm.customerCode.value;
var name=document.userForm.customerName.value;
var letters = /^[A-Za-z]+$/;
var add1=document.userForm.customerAddressOne.value;
var count=0;
var pin=document.userForm.customerPinCode.value;
var connum=document.userForm.contactNumber.value;
var email = document.getElementById('txtEmail');
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

 if (name==null || name=="")
{
alert("Please enter your name.");
      count++;
  }



 if(connum.length<10)
	 {
	 alert('Contact number is invalid');
	 }



if((con.match(numbers)))
{

}
else{
alert('Should be numbers');
count++;}


if(con.length==0)
{
alert('customer field should not be empty');
count++;
}

if(add1.length==0)
{
alert('Address field empty');
count++;
}


if(con.length>10)
{
alert('customer code should be of length less than 10');
count++;
}
if(pin.length!=6)
{
alert('Pin code length should be 6');
count++;
}

if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
   count++;
 }



if(count)
{
alert('Please Enter the Right Details for login');
return false;
}
else {
 return	confirm("are u sure!");
}
}

