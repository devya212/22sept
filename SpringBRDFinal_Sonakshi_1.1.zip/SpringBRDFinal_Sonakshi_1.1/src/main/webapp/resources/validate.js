function emailValidation() {
			var x = document.forms["userForm"]["emailAddress"].value;
			var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			if (x.match(mailformat) && x.length <= 30) {
				return true;
			} else {
				//document.getElementById("error").innerHTML="CUSTOMER Email Not Valid"; 
			     alert("Email not valid or it must be greater than 30 characters"); 
			    document.getElementById("txtEmail").focus();
				return false;
			}

		}
		function validContact() {
			var contact = document.forms["userForm"]["contactNumber"].value;
			var len = contact.length;
			if (len == 10) {

				return true;
			} else {
				/*document.getElementById("error").innerHTML="CUSTOMER Contact Not Valid";
					contactNumber.focus();*/
				alert("Phone number not valid");
				document.getElementById("6").focus();
				return false;
			}
		}
		function namevalidation() {
			var name = document.forms["userForm"]["customerName"].value;
			var letters = /^[A-Za-z ]+$/;
			if (name.match(letters) && name.length < 30) {
				return true;
			} else {
				/* document.getElementById("error").innerHTML="CUSTOMER Name Not Valid";*/
				alert("Name must have alphabet characters only and must be less than 30 characters");
				document.getElementById("2").focus();
				//customerName.focus();
				return false;
			}
		}
		function pincodevalidation() {
			var pin = document.forms["userForm"]["customerPinCode"].value;
			if (pin.length == 6) {
				return true;
			} else {
				//document.getElementById("error").innerHTML="CUSTOMER PinCode Not Valid";
				//customerPinCode.focus();
				alert("PinCode not valid, must have 6 digits");
				document.getElementById("4").focus();
				return false;
			}
		}

		function codevalidation() {
			var code = document.forms["userForm"]["customerCode"].value;
			var letters = /^[0-9]+$/;
			if (code.length <= 10 && code.length > 0 && code.match(letters)) {
				return true;
			} else {
				//document.getElementById("error").innerHTML="CUSTOMER Code Not Valid";
				// customerCode.focus();
				 alert("Code should not be empty / length must be less than 10 characters and must be alpha numeric only");
				 document.getElementById("1").focus();
				return false;
			}
		}

		function addressvalidation() {
			var address = document.forms["userForm"]["customerAddressOne"].value;
			var letters = /^[0-9a-zA-Z ]+$/;
			if (address.match(letters) && address.length > 0) {
				return true;
			} else {
				alert("asdasdasdada");
				document.getElementById("3").focus();
				//document.getElementById("error").innerHTML="CUSTOMER Address Not Valid";
				//customerAddressOne.focus();
				return false;
			}
		}

		function validation() {
			if ( codevalidation()) {
				if ( namevalidation()) {
					if ( addressvalidation()) {
						if (pincodevalidation()) {
							if (emailValidation()) {
								if (validContact()) {
									return confirm("are u sure!");
								} else {
									return false;
								}
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}

		}