function myFunction() {
   /* var txt;*/
    var r = confirm("are u sure!");
    if (r == true) {
       return true;
    } else {
     return false;
    }
    /*document.getElementById("demo").innerHTML = txt;*/
}