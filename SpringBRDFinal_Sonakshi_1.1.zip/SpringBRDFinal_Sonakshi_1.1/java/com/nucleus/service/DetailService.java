package com.nucleus.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.persistence.entity.User;
@Service(value="detailService")
@Transactional(readOnly=true)
public class DetailService implements UserDetailsService{
	@Autowired
	private ServiceDao  serviceDao;
	
	@SuppressWarnings("unused")
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException {
		System.out.println(userName);
		
		User user=serviceDao.findByUsername(userName);
		System.out.println(user.getUserName());
		System.out.println(user.getProfile().getProfile());
		
		if(user==null)
			throw new UsernameNotFoundException("username is not found");
		return new org.springframework.security.core.userdetails.User(user.getUserName(),user.getPassword(),
				AuthorityUtils.createAuthorityList(user.getProfile().getDescription()));

		
	}
	

}

