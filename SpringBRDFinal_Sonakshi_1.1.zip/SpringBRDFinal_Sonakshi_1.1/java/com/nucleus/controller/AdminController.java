package com.nucleus.controller;

public class AdminController {

}
