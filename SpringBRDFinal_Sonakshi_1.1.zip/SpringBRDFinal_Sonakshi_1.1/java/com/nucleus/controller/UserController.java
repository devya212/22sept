package com.nucleus.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nucleus.model.persistence.dao.UserDao;
import com.nucleus.model.persistence.entity.Customer;
import com.nucleus.service.ServiceDao;

@Controller
@RequestMapping
public class UserController {
	@Autowired
	 private UserDao userDao;
		
		/////********login*******************
	 @RequestMapping(value="/login")
	 public String ShowLoginForm(){
		 return "index";
	 }
	 
	 
	 @RequestMapping(value="/",method=RequestMethod.GET)
	 public String Home( Model model,Authentication authentication) {
		 authentication.getPrincipal();
		System.out.println(authentication.getPrincipal());
		
		for (GrantedAuthority a : authentication.getAuthorities()) {
			System.out.println(a.getAuthority());
			if(a.getAuthority().equals("Maker"))
				  return "welcomepage";  
			else
				return "checker";
				
		}
		return null;  
	 }
	 
	
		@Autowired
		private ServiceDao serviceDao;
		
		// ***************add*******************
		@RequestMapping(value ="/adduser", method= RequestMethod.GET)
		public String adduser(Model m)
		{
			
			m.addAttribute("customer",new Customer());
			return "NewUser";
			
		}
		
		@RequestMapping(value ="addnewuser", method= RequestMethod.POST)
		public String addnewUser(@Valid @ModelAttribute("customer") Customer customer,BindingResult result, Model model){
			
			
			if(result.hasErrors()){
				return "NewUser";
			}else{
			
				System.out.println("customer: "+customer);
				model.addAttribute(customer);
			
				serviceDao.addcustomer(customer);
			
			
			return "showCustomer";
			}
		}
		
		//****************delete******************
		@RequestMapping(value ="/deleteuser", method= RequestMethod.GET)
		public String deleteuser()
		{
			
			//m.addAttribute("command",new Customer());
			return "DeleteUser";
			
		}
	 
		@RequestMapping(value ="/delete", method= RequestMethod.POST)
		public String delete(Model model,@RequestParam("customerCode") String customerCode){
			serviceDao.deleteCustomer(customerCode);	
			return "showCustomer";
			
		}
		//******************view one *************
		@RequestMapping(value ="/viewuser", method= RequestMethod.GET)
		public String viewuser()
		{
			
			
			return "ViewOne";
			
		}
	 
		@RequestMapping(value ="/oneview", method= RequestMethod.POST)
		public String oneview(Model model,@RequestParam("customerCode") String customerCode){
			
			System.out.println("hiiiii");
			
			Customer customer = serviceDao.viewCustomer(customerCode);
			model.addAttribute("customer", customer);
			
			
			return "ViewOneTable";
			
		}
		//****************viewall*********************
		
		
		@RequestMapping(value="/viewall", method = RequestMethod.GET)
		public String viewAll(Model model){
			
			List<Customer> customer = serviceDao.viewAll();
			
			model.addAttribute("customer", customer);
			
			return "ViewAll";
					
			
		}
		//**************update***************
		
		@RequestMapping(value="/update", method = RequestMethod.GET)
		public String updateUser(){
			return "UpdateUser";
				
		}
		@RequestMapping(value="/updatevalue",method = RequestMethod.POST)
		public String updateValue( @ModelAttribute Customer customer,Model model,@RequestParam("customerCode") String customerCode){
			
		   customer = serviceDao.viewCustomer(customerCode);
			model.addAttribute("customer", customer);
			
			return "UpdateDetails";
					
		}
		@RequestMapping(value="/updated", method = RequestMethod.POST)
		public String updated(@Valid @ModelAttribute("customer")  Customer customer,BindingResult result){
			if(result.hasErrors())
			{return "UpdateDetails";}
			else{
			serviceDao.updateCustomer(customer);
			return "showCustomer";
			}		
		}
		
		
	 
	 
		 
	 //****************logout****************************
	 	@RequestMapping(value="/Logout", method=RequestMethod.GET)
	 	public String logout(HttpServletRequest req)
	 	{
	 		HttpSession session=req.getSession(false);
	 		session.invalidate();
	 		return "index";
	 	}
	}


