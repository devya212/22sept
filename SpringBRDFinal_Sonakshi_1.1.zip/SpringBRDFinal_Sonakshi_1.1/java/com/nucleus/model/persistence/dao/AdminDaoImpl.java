package com.nucleus.model.persistence.dao;

public class AdminDaoImpl {

}
