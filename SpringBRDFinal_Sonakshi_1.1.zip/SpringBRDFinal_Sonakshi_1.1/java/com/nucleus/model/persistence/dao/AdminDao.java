package com.nucleus.model.persistence.dao;

public interface AdminDao {

}
