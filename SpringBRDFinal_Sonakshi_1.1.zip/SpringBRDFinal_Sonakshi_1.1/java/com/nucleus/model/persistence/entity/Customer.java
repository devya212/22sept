package com.nucleus.model.persistence.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Customer_1276")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE) 
	private int customerId;
	@Column(nullable=false,unique=true)
	@NotEmpty(message="is required")
	private String customerCode;
	
	@NotEmpty(message="is required")
	private String customerName;
	
	@NotEmpty(message="is required")
	private String customerAddress1;
	
	@NotEmpty(message="is required")
	private String customerAddress2;
	
	@NotEmpty(message="is required")
	@Size(max=6,min=6)
	@Pattern(regexp="^[0-9]+$", message="must be a digit")
	private String customerPinCode;
	
	@NotEmpty(message="is required")
	@Email
	private String emailAddress;
	@NotEmpty(message="is required")
	@Size(min=10,max=10)
	@Pattern(regexp = "[0-9]+", message = "Invalid Contact Number")
	private String contactNumber;
	
	@NotEmpty(message="is required")
	private String primaryContactPerson;
	
	private String recordStatus;
	private String Flag;
	@Temporal(TemporalType.DATE)
	private Date createDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	
	public Customer(String customerCode,
			String customerName, String customerAddress1,
			String customerAddress2, String customerPinCode,
			String emailAddress, String contactNumber,
			String primaryContactPerson, String recordStatus,
			String createdBy,String flag) {
		super();
	//	this.customerId = customerId;
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPinCode = customerPinCode;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.primaryContactPerson = primaryContactPerson;
		this.recordStatus = recordStatus;
		this.Flag = flag;
		this.createDate = new Date();
		this.createdBy = createdBy;
		//this.modifiedDate = modifiedDate;
		//this.modifiedBy = modifiedBy;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress1() {
		return customerAddress1;
	}
	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}
	public String getCustomerAddress2() {
		return customerAddress2;
	}
	public void setCustomerAddress2(String customerAddress2) {
		this.customerAddress2 = customerAddress2;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPrimaryContactPerson() {
		return primaryContactPerson;
	}
	public void setPrimaryContactPerson(String primaryContactPerson) {
		this.primaryContactPerson = primaryContactPerson;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getFlag() {
		return Flag;
	}
	public void setFlag(String Flag) {
		this.Flag = Flag;
	}
	public Date getCreateDate() {
		return createDate;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress1=" + customerAddress1 + ", customerAddress2=" + customerAddress2
				+ ", customerPinCode=" + customerPinCode + ", emailAddress=" + emailAddress + ", contactNumber="
				+ contactNumber + ", primaryContactPerson=" + primaryContactPerson + ", recordStatus="
				+ recordStatus + ", Flag=" + Flag + ", createDate=" + createDate + ", createdBy=" + createdBy
				+ ", modifiedDate=" + modifiedDate + ", modifiedBy=" + modifiedBy + "]";
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
}
