package com.nucleus.model.persistence.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="User_1276")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int id;
	@Column(name="User_Name")
	@NotEmpty(message="is required")
	private String userName;
	@Column(name="password")
	@NotEmpty(message="is required")
	private String password;
	@Column(name="enabled")
	@NotEmpty(message="is required")
	private int enabled;
	@OneToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
private Profile profile;
	public User(){};
	
	public User(String userName, String password, Profile profile,int enabled) {
		super();
		this.userName = userName;
		this.password = password;
		this.profile = profile;
	}

	
	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}


}
